simpleSequence <- 1:4
simpleSequence == 2
stringSequence <- c("A", "B", "C", "D", "E", "F", "G", "H")
nchar(stringSequence)
funkySequence <- paste(stringSequence, simpleSequence, sep="")
funkySequence

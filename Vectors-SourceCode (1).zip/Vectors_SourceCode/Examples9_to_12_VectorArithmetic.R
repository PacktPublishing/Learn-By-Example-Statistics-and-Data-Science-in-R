denominations <- c(1, 5, 10, 20, 50, 100, 500)
amountPerDenomination <- denominations * 30
amountPerDenomination
# the same using a for loop 
amountPerDen <- numeric()
for(i in denominations) {
  amountPerDen <- c(amountPerDen , i*30)
}
amountPerDen

totalAmountInBank <- sum(amountPerDenomination)

startMoney <- c(5, 5, 5, 6, 2, 2, 2)
startAmountPerDen <- startMoney * denominations
startAmountPerDen

playerMoney <- numeric(6) + sum(startAmountPerDen)
playerMoney

playerMoney <- playerMoney + c(100,0)
playerMoney
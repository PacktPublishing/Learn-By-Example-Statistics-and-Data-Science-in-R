playerMoney <- c(247, 350, 130, 4000, 600)
playerMoney
mode(playerMoney)
startPlayerMoney <- numeric(5)
startPlayerMoney
playerNames <- c(1, 2, "Dave", "Gru", "Edith")
playerNames
playerMoneyTrend <- c(startPlayerMoney, playerMoney)
playerMoneyTrend

mySequence <- 3*1:5
mySequence
mySequence[1]
mySequence[2:4]
mySequence[rep(c(1,3), times = 5)]
mySequence[c(-3, -4)]
mySequence[mySequence > 10]
mySequence[mySequence != 9] <- -mySequence[mySequence != 9]
mySequence
mySequence[c(TRUE,FALSE)]
names(mySequence) <- c("A","B","C","D","E")
mySequence[c("A","C")]
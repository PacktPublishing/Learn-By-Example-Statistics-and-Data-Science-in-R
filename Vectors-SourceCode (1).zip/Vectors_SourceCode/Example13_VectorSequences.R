simpleSequence <- 1:10
simpleSequence
evenNumberSequence <- 2*1:5
evenNumberSequence
reverseSequence <- 10:1
reverseSequence
repeatSequence <- rep(evenNumberSequence, times = 2, length.out = 20, each = 3)
repeatSequence
generalSequence <- seq(from = -5, to = 10, by = 0.2)
generalSequence
generalSequence2 <- seq(from = -5, to = 10, length.out = 10)
generalSequence2
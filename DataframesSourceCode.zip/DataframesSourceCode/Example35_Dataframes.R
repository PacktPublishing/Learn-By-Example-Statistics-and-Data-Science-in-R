playerNames <- c("Sachin","Dravid","Mcgrath","Warne","Jayawardane","Dhoni")
teams <- c("India","India","Australia","Australia","Sri Lanka","India")
scores <- c(120, 108, 98, 45, 115, 100)
cricInfo <- data.frame(playerNames, teams, scores)
cricInfo
head(cricInfo,3)
nrow(cricInfo)
ncol(cricInfo)
names(cricInfo)
rownames(cricInfo)
dim(cricInfo)
scoresExtra <- c(scores,20)
cricInfoNew <- data.frame(playerNames, teams, scores = c(scores,20))
cricInfoNew

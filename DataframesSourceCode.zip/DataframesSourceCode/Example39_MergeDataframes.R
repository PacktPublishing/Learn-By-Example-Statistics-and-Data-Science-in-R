df1 <- data.frame(custId = 1:3, custName = c("Vitthal","Janani","Navdeep"))
df1
df2 <- data.frame(custId = 1:3, custAge = c(36,36,26))
df2
df3 <- merge(df1, df2, by="custId")
df3
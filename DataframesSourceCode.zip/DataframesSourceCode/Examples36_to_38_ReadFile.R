# Example 36
u.user <- "/Users/swethakolalapudi/Downloads/ml-100k/u.user"
header <- c("userId","age","gender","occupation","zipCode")
userInfo <- read.table(u.user,header = FALSE, sep ="|", quote = "\"'",
                       col.names = header)
head(userInfo,10)
#Example 37
userInfo[2:5,1:2]
userInfo$age[1:10]
class(userInfo$gender)
length(levels(userInfo$occupation))

#Example 38
aggregate(age ~ gender, userInfo, mean)
aggregate(age ~ gender + occupation, userInfo, mean)
occupationCounts <- aggregate(userId ~ occupation, userInfo, length)
head(occupationCounts[order(occupationCounts$userId, decreasing = TRUE),],3)
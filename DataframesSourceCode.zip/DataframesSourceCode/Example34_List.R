family <- list("Mom","Dad", c("Kid1","Kid2","Kid3"),3,c(4,5,7))
names(family) <- c("Mother","Father","Kids","no.Kids","ages.of.Kids")
family[1]
family[[1]]
family$Mother


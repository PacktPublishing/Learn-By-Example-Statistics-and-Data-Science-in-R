iAmCharacter <- "any string"
class(iAmCharacter)
nchar(iAmCharacter)

iAmDate <- as.Date("2016-02-17 00:29")
iAmDate
class(iAmDate)
as.numeric(iAmDate)
iAmDateToo <- as.Date("2016-02-14 00:29")
iAmDate-iAmDateToo
class(iAmDate-iAmDateToo)
as.numeric(iAmDate-iAmDateToo)

iAmTimeStamp <- as.POSIXct("2016-02-17 00:29")
iAmTimeStamp
class(iAmTimeStamp)
as.numeric(iAmTimeStamp)
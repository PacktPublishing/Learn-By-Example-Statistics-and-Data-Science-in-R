3
3+5
myFirstVar <- 3
mySecondVar <- 5
myFirstVar
myFirstVar + mySecondVar
print(mySecondVar)
show(myFirstVar)
this.Silly.Var <- that.Silly.Var <- "silly"
cat(this.Silly.Var, ",", that.Silly.Var, "are both the same", sep = " ")
sillyMessage = paste(this.Silly.Var, ",", that.Silly.Var, "are both the same", sep = " ")
message(sillyMessage)






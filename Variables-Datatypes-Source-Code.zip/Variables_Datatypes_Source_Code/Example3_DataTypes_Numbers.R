iAmNumber <- 2.5
iAmNumberToo <- 3+5
class(iAmNumber)
is.numeric(iAmNumberToo)
is.integer(iAmNumberToo)

iAmInteger <- 4L
is.integer(iAmInteger)
iAmIntegerToo <- as.integer(3+5)
class(iAmIntegerToo)
is.numeric(iAmInteger)

iAmDouble <- as.double(4)
is.double(iAmDouble)
is.integer(iAmDouble)
is.numeric(iAmDouble)







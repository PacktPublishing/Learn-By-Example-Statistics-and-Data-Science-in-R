iAmTrue <- TRUE
class(iAmTrue)

iAmFalse <- FALSE
class(iAmFalse)

iAmNumber <- 5
iAmFalse * iAmNumber

iAmTrue * iAmNumber 

iAmLogical <- 2 == 3
iAmLogical

iAmLogicalToo <- 2 != 3
iAmLogicalToo

iCompareCharacters <- "Red" > "Blue"
iCompareCharacters

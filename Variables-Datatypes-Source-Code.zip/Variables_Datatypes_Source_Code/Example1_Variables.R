myFirstVar = 3
mySecondVar <- 5
2.5 -> anotherVar
this.Silly.Var <- that.Silly.Var <- "silly"
assign("funnyWayToAssignVar", 20)







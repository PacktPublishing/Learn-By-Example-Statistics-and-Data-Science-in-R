# CREATING A MATRIX
aMatrix <- matrix(c(2*1:3, 3*1:3), nrow = 2, ncol = 3)
aMatrix
nrow(aMatrix)
ncol(aMatrix)
# MATRIX TRANSPOSE
t(aMatrix)
anotherMatrix <- t(aMatrix)
# MATRIX MULTIPLICATION
aMatrix %*% anotherMatrix 
# CROSSPRODUCT OF A, B == t(A) %*% B
crossprod(aMatrix,2*1:2)
# CONCATENATING MATRICES OR VECTORS 
cbind(aMatrix, 1:2)
rbind(aMatrix, 1:3)
# SOLVING AN EQUATION
coeffMatrix <- matrix(c(1,-1,8,-8,1,1,4,4,1,-1,2,-2,1,1,1,1), nrow = 4)
constMatrix <- c(-3, -1, -13, -21)
solve(coeffMatrix, constMatrix)



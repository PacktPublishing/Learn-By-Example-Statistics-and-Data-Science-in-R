googFile <- '/Users/swethakolalapudi/Desktop/Regression/goog.csv'
nasdaqFile <-'/Users/swethakolalapudi/Desktop/Regression/nasdaq.csv'
# Example 2
# Preprocessing the data
goog <-read.table(googFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
  names(goog)[2]<-"goog.price"
  nasdaq <- read.table(nasdaqFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
  names(nasdaq)[2]<-"nasdaq.price"
  goog <- merge(goog, nasdaq, by = "Date")
  goog[,c("Date")] <- as.Date(goog[,c("Date")])
  goog <- goog[order(goog$Date, decreasing = TRUE),]
  goog[-nrow(goog),-1] <- goog[-nrow(goog),-1]/goog[-1,-1]-1
  goog <- goog[-nrow(goog),]
  tbonds <- read.table('/Users/swethakolalapudi/Desktop/Regression/tbond5yr.csv',header = TRUE, sep =",")[,c("Date","Adj.Close")]
  names(tbonds)[2]<-"tbonds.returns"
  tbonds[,c("Date")] <- as.Date(tbonds[,c("Date")])
  goog <- merge(goog, tbonds, by="Date")
  goog$tbonds.returns <- goog$tbonds.returns/100
  names(goog)[2:3] <- c("goog.returns","nasdaq.returns")
  goog[,c("goog.returns","nasdaq.returns")] <- goog[,c("goog.returns","nasdaq.returns")]-goog[,"tbonds.returns"]

# Building a linear model
googM <- lm(goog$goog.returns~goog$nasdaq.returns)
summary(googM)

# Put all of the preprocessing in a function
preProcess <- function(googFile,nasdaqFile){
  goog <-read.table(googFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
  names(goog)[2]<-"goog.price"
  nasdaq <- read.table(nasdaqFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
  names(nasdaq)[2]<-"nasdaq.price"
  goog <- merge(goog, nasdaq, by = "Date")
  goog[,c("Date")] <- as.Date(goog[,c("Date")])
  goog <- goog[order(goog$Date, decreasing = TRUE),]
  goog[-nrow(goog),-1] <- goog[-nrow(goog),-1]/goog[-1,-1]-1
  goog <- goog[-nrow(goog),]
  tbonds <- read.table('/Users/swethakolalapudi/Desktop/Regression/tbond5yr.csv',header = TRUE, sep =",")[,c("Date","Adj.Close")]
  names(tbonds)[2]<-"tbonds.returns"
  tbonds[,c("Date")] <- as.Date(tbonds[,c("Date")])
  goog <- merge(goog, tbonds, by="Date")
  goog$tbonds.returns <- goog$tbonds.returns/100
  names(goog)[2:3] <- c("goog.returns","nasdaq.returns")
  goog[,c("goog.returns","nasdaq.returns")] <- goog[,c("goog.returns","nasdaq.returns")]-goog[,"tbonds.returns"]
  return(goog)}

# use the function for preprocessing
goog <- preProcess(googFile,nasdaqFile)

#Build a linear model that accounts for missing values
googM <- lm(goog$goog.returns~goog$nasdaq.returns, na.action = na.omit)

# Deal with missing values in the preprocessing step itself
goog[,"goog.returns"][is.na(goog[,"goog.returns"])] <- mean(goog[,"goog.returns"])



# Example 3 : Multiple linear regression 
xomFile <- '/Users/swethakolalapudi/Desktop/Regression/xom.csv'
snpFile <-'/Users/swethakolalapudi/Desktop/Regression/snp.csv'
xom <- preProcess(xomFile,snpFile)
names(xom)[2:3] <- c("xom.returns","snp.returns" )
xom_SM <- lm(xom$xom.returns~xom$snp.returns)
summary(xom_SM)

uso <- read.table('/Users/swethakolalapudi/Desktop/Regression/uso.csv',header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(uso)[2]<-"uso.returns"
uso[,c("Date")] <- as.Date(uso[,c("Date")])
uso <- uso[order(uso$Date, decreasing = TRUE),]
uso[-nrow(uso),-1] <- uso[-nrow(uso),-1]/uso[-1,-1]-1
xom <- merge(xom, uso, by = "Date")

xom_MLR <- lm(xom$xom.returns~xom$snp.returns + xom$uso.returns)
summary(xom_MLR)

# Example 4: Including a categorical variable
goog$Month = format(goog$Date,"%m")
dummyVars <- model.matrix(~Month,goog)
goog_MLR <- lm(goog$goog.returns~goog$nasdaq.returns+goog$Month)
summary(goog_MLR)

# Example 5 : Robust linear regression 
plot(goog$nasdaq.returns,goog$goog.returns)
abline(googM)
require(MASS)
googRLM <- rlm(goog$goog.returns~goog$nasdaq.returns)
abline(googRLM, lty ='twodash')

# Example 6 : Diagnostic plots 
plot(googM) 

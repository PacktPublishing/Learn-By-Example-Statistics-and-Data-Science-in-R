x <- array(1:10, dim = 10)
y <- 1:10
x %o% y
A <- array(1:18, dim = c(3,2,3))
B <- array(19:36, dim = c(2,3,3))
AB <- A %o% B
dim(AB)
AB[1,2,1,2,1,1]
A[1,2,1] * B[2,1,1]
outerSumAB <- outer(A, B, "+")


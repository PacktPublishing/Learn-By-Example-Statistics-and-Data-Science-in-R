myVector <- 1:10
myVector
myArray <- myVector 
dim(myArray) <- c(5,2)
myArray
anotherArray <- array(c(1:12), dim = c(3,2,2))
anotherArray
thirdArray <- array(c(1,0) , dim = c(2,3))
thirdArray
anotherArray[2,2,1]
anotherArray[2:3,,1]
indexArray <- array (c(1:2), dim=c(2,3))
indexArray
anotherArray[indexArray]
a <- array(1:6, dim = c(2,3))
b <- array(7:12, dim = c(2,3))
c <- array(13:18, dim = c(3,2))
a * b
# a-c 
sameLength <- 1:6
shorterVector <- 1:2
longerVector <- 1:10
a + sameLength
a - shorterVector
#a / longerVector
a
city <- c("Bangalore", "New Delhi", "Mumbai", "Bangalore", "Bangalore", "Mumbai", "New Delhi")
category <- c("Clothing", "Footwear", "Cosmetics", "Cosmetics", "Footwear", "Clothing", "Clothing")
saleAmount <- c(5000, 4500, 3500, 2500, 1000, 2000, 5500)
# Example 29
cityAsFactor <- factor(city)
print(cityAsFactor)
as.numeric(cityAsFactor)
#Example 30
levels(cityAsFactor)
levels(cityAsFactor) <- c("BLR", "MUM", "DEL")
#Example 31
cityCodeFactor <- factor(cityAsFactor, labels=c("B", "M", "D"))
print(cityCodeFactor)

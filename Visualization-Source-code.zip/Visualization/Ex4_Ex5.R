library(RColorBrewer)
library(datasets)

#Ex4
data(HairEyeColor)
heatmap(HairEyeColor[,,1])

#Ex5
data(iris)
plot(iris)


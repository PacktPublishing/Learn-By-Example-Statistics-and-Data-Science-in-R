x <- 1:10 
y <- rnorm(10)
par(mfrow=c(1,2))
plot(x,y,type="p",main="ScatterPlot",xlab="X",ylab="Y")
plot(x,y,type="l",main="Line",xlab="X",ylab="Y")

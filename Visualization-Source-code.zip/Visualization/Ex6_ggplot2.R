googFile <- '/Users/swethakolalapudi/Desktop/Regression/goog.csv'
nasdaqFile <-'/Users/swethakolalapudi/Desktop/Regression/nasdaq.csv'
xomFile <- '/Users/swethakolalapudi/Desktop/Regression/xom.csv'
snpFile <-'/Users/swethakolalapudi/Desktop/Regression/snp.csv'

goog <-read.table(googFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
goog["Series"] <- "Goog"

nasdaq <-read.table(nasdaqFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
nasdaq["Series"] <- "Nasdaq"

xom <-read.table(xomFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
xom["Series"] <- "Exxon Mobil"

snp <-read.table(snpFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
snp["Series"] <- "S&P 500"

data <- rbind(goog,nasdaq,xom,snp)
data$Date <- as.Date(data$Date)
require(ggplot2)
ggplot(data, aes(Date,Adj.Close)) + geom_line(aes(colour = Series))

